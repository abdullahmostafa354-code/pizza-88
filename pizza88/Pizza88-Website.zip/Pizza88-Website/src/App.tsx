import { useState } from "react";
import { ArrowUpRight, Star, Utensils, X, ChevronLeft, ChevronRight } from "lucide-react";

// Google Maps / restaurant review link supplied by you:
const REVIEW_URL = "https://www.google.com/maps/place/Pizza+88/@31.196936,29.9032521,12z/data=!4m12!1m2!2m1!1spizza+88!3m8!1s0x14f5c30053aee123:0xd3420db778011664!8m2!3d31.196936!4d29.9032521!9m1!1b1!15sCghwaXp6YSA4OFoKIghwaXp6YSA4OJIBEHBpenphX3Jlc3RhdXJhbnSaAURDaTlEUVVsUlFVTnZaRU5vZEhsalJqbHZUMnRqZUdOSFVrbE5Sa1pJWVRGU2QxRlVSbGROUjNNeFUxUktObFJ1WXhBQuABAPoBBAgAECM!16s%2Fg%2F11myr6wvjk?hl=en-US&entry=ttu&g_ep=EgoyMDI2MTEwMy4wIKXMDSoASAFQAw%3D%3D";

// Put menu images in public/menu and add their filenames here:
const MENU_IMAGES: string[] = []; // Example: ["menu-1.jpg", "menu-2.jpg"]

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [selected, setSelected] = useState<number | null>(null);
  const prev = () => setSelected(i => i === null ? null : (i - 1 + MENU_IMAGES.length) % MENU_IMAGES.length);
  const next = () => setSelected(i => i === null ? null : (i + 1) % MENU_IMAGES.length);

  return <main className="page">
    <header><a className="logo" href="#"><span>88</span> PIZZA <b>88</b></a><small>● &nbsp; FRESHLY BAKED</small></header>
    <section className="hero">
      <div className="copy">
        <p className="eyebrow">✦ &nbsp; GOOD FOOD. GOOD MOOD.</p>
        <h1>THE TASTE<br/>YOU <em>LOVE.</em></h1>
        <p className="intro">Made to bring people together. Explore our menu and discover your next favourite pizza.</p>
        <div className="buttons">
          <button className="btn primary" onClick={() => setMenuOpen(true)}><i><Utensils/></i><span><strong>VIEW OUR MENU</strong><small>Find your perfect slice</small></span><ArrowUpRight/></button>
          <a className="btn secondary" href={REVIEW_URL} target="_blank" rel="noreferrer"><i><Star/></i><span><strong>RATE OUR RESTAURANT</strong><small>Your feedback means a lot</small></span><ArrowUpRight/></a>
        </div>
        <p className="thanks">✦ &nbsp; THANK YOU FOR CHOOSING PIZZA 88</p>
      </div>
      <div className="pizza-art"><div className="ring"></div><div className="ring ring2"></div><span>🍕</span><b>88</b><label>FRESH INGREDIENTS</label><label className="love">MADE WITH LOVE ♥</label></div>
    </section>
    <footer><span>© {new Date().getFullYear()} PIZZA 88</span><span>MADE FOR PIZZA LOVERS ♥</span></footer>

    {menuOpen && <div className="overlay" onClick={() => setMenuOpen(false)}>
      <section className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-head"><div><small>PIZZA 88</small><h2>OUR <em>MENU</em></h2></div><button className="close" onClick={() => setMenuOpen(false)}><X/></button></div>
        {MENU_IMAGES.length === 0 ? <div className="empty"><Utensils size={34}/><h3>YOUR MENU WILL APPEAR HERE</h3><p>ضع صور المنيو داخل <code>public/menu</code>، ثم اكتب أسماء الصور في قائمة MENU_IMAGES داخل src/App.tsx.</p><button onClick={() => setMenuOpen(false)}>BACK TO HOME</button></div> :
        <div className="gallery">{MENU_IMAGES.map((file,i)=><button className="menu-card" key={file} onClick={()=>setSelected(i)}><img src={"/menu/"+file} alt={"Menu page "+(i+1)}/><small>PAGE {i+1}</small></button>)}</div>}
      </section>
    </div>}

    {selected !== null && MENU_IMAGES[selected] && <div className="viewer" onClick={()=>setSelected(null)}>
      <button className="x" onClick={()=>setSelected(null)}><X/></button>
      {MENU_IMAGES.length>1 && <button className="arrow left" onClick={e=>{e.stopPropagation();prev();}}><ChevronLeft/></button>}
      <img src={"/menu/"+MENU_IMAGES[selected]} onClick={e=>e.stopPropagation()} alt="Menu"/>
      {MENU_IMAGES.length>1 && <button className="arrow right" onClick={e=>{e.stopPropagation();next();}}><ChevronRight/></button>}
      <small>{selected+1} / {MENU_IMAGES.length}</small>
    </div>}
  </main>;
}